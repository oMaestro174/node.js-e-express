const express = require('express');
const router = express.Router();

const {
  listarAlunos,
  adicionarAluno
} = require('../services/alunosService');

// GET /alunos
router.get('/', (req, res) => {
  const lista = listarAlunos();
  res.status(200).json(lista);
});

// POST /alunos
router.post('/', (req, res) => {
  const novoAluno = req.body;

  if (!novoAluno.nome) {
    return res.status(400).json({ erro: 'Nome é obrigatório' });
  }

  adicionarAluno(novoAluno);
  res.status(201).json(novoAluno);
});

module.exports = router;