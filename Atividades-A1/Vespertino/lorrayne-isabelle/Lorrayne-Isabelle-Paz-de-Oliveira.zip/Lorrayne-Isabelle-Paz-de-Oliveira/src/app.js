const express = require('express');
const app = express();

const alunosRoutes = require('./rotas/alunos');

// Habilita JSON
app.use(express.json());

// Usa as rotas
app.use('/alunos', alunosRoutes);

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
